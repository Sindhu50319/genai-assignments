/**
 * Collection of default prompts for different use cases (ICE POT Format)
 */
export const DEFAULT_PROMPTS = {
 
  /**
   * Selenium Java Page Object Prompt (No Test Class)
   */
  SELENIUM_JAVA_PAGE_ONLY: `
    Instructions:
    - Generate ONLY a Selenium Java Page Object Class (no test code).
    - Add JavaDoc for methods & class.
    - Use Selenium 2.30+ compatible imports.
    - Use meaningful method names.
    - Do NOT include explanations or test code.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`java
    package com.testleaf.pages;

    /**
     * Page Object for Component Page
     */
    public class ComponentPage {
        // Add methods as per the DOM
    }
    \`\`\`

    Persona:
    - Audience: Automation engineer focusing on maintainable POM structure.

    Output Format:
    - A single Java class inside a \`\`\`java\`\`\` block.

    Tone:
    - Clean, maintainable, enterprise-ready.
  `,

  /**
   * Cucumber Feature File Only Prompt
   */
  CUCUMBER_ONLY: `
    Instructions:
    - Generate ONLY a Cucumber (.feature) file.
    - Use Scenario Outline with Examples table.
    - Make sure every step is relevant to the provided DOM.
    - Do not combine multiple actions into one step.
    - Use South India realistic dataset (names, addresses, pin codes, mobile numbers).
    - Use dropdown values only from provided DOM.
    - Generate multiple scenarios if applicable.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully

    Examples:
      | username   | password  |
      | "testuser" | "testpass"|
      | "admin"    | "admin123"|
    \`\`\`

    Persona:
    - Audience: BDD testers who only need feature files.

    Output Format:
    - Only valid Gherkin in a \`\`\`gherkin\`\`\` block.

    Tone:
    - Clear, structured, executable.
  `,

  /**
   * Cucumber with Step Definitions
   */
  CUCUMBER_WITH_SELENIUM_JAVA_STEPS: `
    Instructions:
    - Generate BOTH:
      1. A Cucumber .feature file.
      2. A Java step definition class for selenium.
    - Do NOT include Page Object code.
    - Step defs must include WebDriver setup, explicit waits, and actual Selenium code.
    - Use Scenario Outline with Examples table (South India realistic data).

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully

    Examples:
      | username   | password  |
\      | "admin"    | "admin123"|
    \`\`\`

    \`\`\`java
    package com.leaftaps.stepdefs;

    import io.cucumber.java.en.*;
    import org.openqa.selenium.*;
    import org.openqa.selenium.chrome.ChromeDriver;
    import org.openqa.selenium.support.ui.*;

    public class LoginStepDefinitions {
        private WebDriver driver;
        private WebDriverWait wait;

        @io.cucumber.java.Before
        public void setUp() {
            driver = new ChromeDriver();
            wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            driver.manage().window().maximize();
        }

        @io.cucumber.java.After
        public void tearDown() {
            if (driver != null) driver.quit();
        }

        @Given("I open the login page")
        public void openLoginPage() {
            driver.get("\${pageUrl}");
        }

        @When("I type {string} into the Username field")
        public void enterUsername(String username) {
            WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.id("username")));
            el.sendKeys(username);
        }

        @When("I type {string} into the Password field")
        public void enterPassword(String password) {
            WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.id("password")));
            el.sendKeys(password);
        }

        @When("I click the Login button")
        public void clickLogin() {
            driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
        }

        @Then("I should be logged in successfully")
        public void verifyLogin() {
            WebElement success = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("success")));
            assert success.isDisplayed();
        }
    }
    \`\`\`

    Persona:
    - Audience: QA engineers working with Cucumber & Selenium.

    Output Format:
    - Gherkin in \`\`\`gherkin\`\`\` block + Java code in \`\`\`java\`\`\` block.

    Tone:
    - Professional, executable, structured.
  `,

  /**
   * Functional Test Cases Generation Prompt
   */
  TEST_CASES_ONLY: `
    Instructions:
    - Generate EXACTLY 5 functional test cases.
    - Include ONLY Priority P1 and P2 functional test cases.
    - Do NOT generate duplicate test cases.
    - Generate only functional test cases relevant to the generated automation flow.
    - Format output as a JSON array of test case objects.
    - Each test case must have the following structure:
      {
        "scenario": "Description of what is being tested",
        "steps": "Step-by-step actions to perform",
        "expected_result": "Expected outcome after performing the steps",
        "actual_result": "Field for actual result (leave empty in generation)"
      }

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Programming Language: \${language}
    Browser Engine: \${engine}

    Example Output:
    \`\`\`json
    [
      {
        "scenario": "User successfully logs in with valid credentials",
        "steps": "1. Navigate to login page\\n2. Enter valid username\\n3. Enter valid password\\n4. Click login button",
        "expected_result": "User is redirected to dashboard page",
        "actual_result": ""
      },
      {
        "scenario": "User receives error message with invalid credentials",
        "steps": "1. Navigate to login page\\n2. Enter invalid username\\n3. Enter invalid password\\n4. Click login button",
        "expected_result": "Error message is displayed",
        "actual_result": ""
      }
    ]
    \`\`\`

    Persona:
    - Audience: QA engineers and automation testers.

    Output Format:
    - ONLY a valid JSON array in a \`\`\`json\`\`\` code block.
    - No explanations, no extra text.

    Tone:
    - Clear, concise, functional, and comprehensive.
  `,

  /**
   * Playwright TypeScript Page Object Prompt
   */
  PLAYWRIGHT_TYPESCRIPT_PAGE_ONLY: `
    Instructions:
    - Generate ONLY a Playwright TypeScript Page Object Class (no test code).
    - Use Playwright v1.40+ compatible imports.
    - Add JSDoc comments for methods & class.
    - Use meaningful method names and strong typing.
    - Include locator definitions as class properties.
    - Use async/await patterns.
    - Do NOT include explanations or test code.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`typescript
    import { Page, Locator } from '@playwright/test';

    /**
     * Page Object for Login Component
     */
    export class LoginPage {
      readonly page: Page;
      readonly usernameField: Locator;
      readonly passwordField: Locator;
      readonly loginButton: Locator;

      constructor(page: Page) {
        this.page = page;
        this.usernameField = page.locator('#username');
        this.passwordField = page.locator('#password');
        this.loginButton = page.locator('button:has-text("Login")');
      }

      /**
       * Fill username field
       */
      async fillUsername(username: string): Promise<void> {
        await this.usernameField.fill(username);
      }

      /**
       * Fill password field
       */
      async fillPassword(password: string): Promise<void> {
        await this.passwordField.fill(password);
      }

      /**
       * Click login button
       */
      async clickLogin(): Promise<void> {
        await this.loginButton.click();
      }
    }
    \`\`\`

    Persona:
    - Audience: Automation engineer focusing on maintainable POM structure with TypeScript.

    Output Format:
    - A single TypeScript class inside a \`\`\`typescript\`\`\` block.

    Tone:
    - Clean, maintainable, enterprise-ready, type-safe.
  `,

  /**
   * Playwright TypeScript Test File Prompt
   */
  PLAYWRIGHT_TYPESCRIPT_TESTS: `
    Instructions:
    - Generate ONLY Playwright test file(s) using TypeScript.
    - Use @playwright/test framework with fixtures.
    - Include multiple test scenarios based on the DOM.
    - Add assertions for expected outcomes.
    - Use data-driven approach with test data.
    - Include setup and teardown with proper typing.
    - Use descriptive test names.
    - Do NOT include Page Object code.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`typescript
    import { test, expect, Page } from '@playwright/test';

    const TEST_DATA = [
      { username: 'admin', password: 'admin123', expectedSuccess: true },
      { username: 'user', password: 'user123', expectedSuccess: true },
      { username: 'invalid', password: 'wrong', expectedSuccess: false }
    ];

    test.describe('Login Page Tests', () => {
      let page: Page;

      test.beforeEach(async ({ browser }) => {
        page = await browser.newPage();
        await page.goto('\${pageUrl}');
      });

      test.afterEach(async () => {
        await page.close();
      });

      test.describe.each(TEST_DATA)('Login with credentials', ({ username, password, expectedSuccess }) => {
        test(\`should \${expectedSuccess ? 'successfully' : 'fail to'} login with \${username}\`, async () => {
          await page.fill('#username', username);
          await page.fill('#password', password);
          await page.click('button:has-text("Login")');

          if (expectedSuccess) {
            await expect(page).toHaveURL(/.*dashboard.*/);
          } else {
            await expect(page.locator('.error-message')).toBeVisible();
          }
        });
      });
    });
    \`\`\`

    Persona:
    - Audience: Automation engineers using Playwright with TypeScript.

    Output Format:
    - Only TypeScript test code in a \`\`\`typescript\`\`\` code block.
    - Include multiple test scenarios.

    Tone:
    - Professional, test-focused, type-safe, comprehensive.
  `,

  /**
   * Playwright TypeScript with Page Object (Combined) Prompt
   */
  PLAYWRIGHT_TYPESCRIPT_WITH_PAGE_OBJECT: `
    Instructions:
    - Generate BOTH:
      1. A Playwright TypeScript Page Object class.
      2. A Playwright TypeScript test file using the Page Object.
    - Use @playwright/test framework with fixtures.
    - Include strong typing for all parameters and return types.
    - Add JSDoc documentation for all methods.
    - Implement multiple test scenarios with data-driven approach.
    - Use Locator strategy best practices.
    - Include proper wait/retry logic using Playwright's built-in features.
    - Both files should be well-organized and maintainable.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    Page Object:
    \`\`\`typescript
    import { Page, Locator } from '@playwright/test';

    export class LoginPage {
      readonly page: Page;
      readonly usernameField: Locator;
      readonly passwordField: Locator;
      readonly loginButton: Locator;
      readonly errorMessage: Locator;

      constructor(page: Page) {
        this.page = page;
        this.usernameField = page.locator('#username');
        this.passwordField = page.locator('#password');
        this.loginButton = page.locator('button:has-text("Login")');
        this.errorMessage = page.locator('.error-message');
      }

      async navigateTo(): Promise<void> {
        await this.page.goto('\${pageUrl}');
      }

      async login(username: string, password: string): Promise<void> {
        await this.usernameField.fill(username);
        await this.passwordField.fill(password);
        await this.loginButton.click();
      }

      async isErrorMessageVisible(): Promise<boolean> {
        return this.errorMessage.isVisible();
      }
    }
    \`\`\`

    Test File:
    \`\`\`typescript
    import { test, expect } from '@playwright/test';
    import { LoginPage } from './pages/login.page';

    test.describe('Login Feature', () => {
      let loginPage: LoginPage;

      test.beforeEach(async ({ page }) => {
        loginPage = new LoginPage(page);
        await loginPage.navigateTo();
      });

      test('TC001: Should successfully login with valid credentials', async () => {
        await loginPage.login('admin', 'admin123');
        await expect(loginPage.page).toHaveURL(/.*dashboard.*/);
      });

      test('TC002: Should show error with invalid credentials', async () => {
        await loginPage.login('invalid', 'wrong');
        const errorVisible = await loginPage.isErrorMessageVisible();
        expect(errorVisible).toBe(true);
      });
    });
    \`\`\`

    Persona:
    - Audience: QA engineers and automation architects using Playwright with TypeScript.

    Output Format:
    - Page Object in \`\`\`typescript\`\`\` block + Test file in \`\`\`typescript\`\`\` block.
    - Both files fully functional and production-ready.

    Tone:
    - Professional, enterprise-ready, type-safe, maintainable, well-documented.
  `
};

/**
 * Helper function to escape code blocks in prompts
 */
function escapeCodeBlocks(text) {
  return text.replace(/```/g, '\\`\\`\\`');
}

/**
 * Function to fill template variables in a prompt
 */
export function getPrompt(promptKey, variables = {}) {
  let prompt = DEFAULT_PROMPTS[promptKey];
  if (!prompt) {
    throw new Error(`Prompt not found: ${promptKey}`);
  }

  Object.entries(variables).forEach(([k, v]) => {
    const regex = new RegExp(`\\$\\{${k}\\}`, 'g');
    prompt = prompt.replace(regex, v);
  });

  return prompt.trim();
}

export const CODE_GENERATOR_TYPES = {
  SELENIUM_JAVA_PAGE_ONLY: 'Selenium-Java-Page-Only',
  CUCUMBER_ONLY: 'Cucumber-Only',
  CUCUMBER_WITH_SELENIUM_JAVA_STEPS: 'Cucumber-With-Selenium-Java-Steps',
  TEST_CASES_ONLY: 'Test-Cases-Only',
  PLAYWRIGHT_TYPESCRIPT_PAGE_ONLY: 'Playwright-TypeScript-Page-Only',
  PLAYWRIGHT_TYPESCRIPT_TESTS: 'Playwright-TypeScript-Tests',
  PLAYWRIGHT_TYPESCRIPT_WITH_PAGE_OBJECT: 'Playwright-TypeScript-With-Page-Object',
};
